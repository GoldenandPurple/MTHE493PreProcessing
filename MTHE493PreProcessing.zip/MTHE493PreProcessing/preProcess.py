import pandas as pd
import re
import collections as col

"""
Pre-Processing Code - Gutenberg Data Set
Wesley Routley - MTHE '19

The following code was used to process the
books from the Gutenberg Project website.

It's a brute force approach... I didn't
care enough to make some beautiful solution.
Feel free to do that, I guess. 

Save the criticism. I'm aware that it's
shite code, but it's *my* shite code all the
same.

"""

"""
Part I: Set Creation

For each book, the .txt file was opened and read into
a string. The non-alphabetic characters were removed
using re, and the remaining words separated into a
list. The lists were converted into Counters in order
to obtain the frequency of each word present. Further
processing of the Counters occur after this block.

Assuming that each book is encoded using UTF-8 is 
a mistake... as a result, you will get some artifacts
(apostrophes, lonely letters, etc) that you'll need
to clean up after the final output. Sue me.

"""

book = open("100.txt", encoding='utf-8')
str = book.read()
regex = re.compile("[^a-zA-Z ']")
newBook = regex.sub(' ', str)
newestBook = " ".join(newBook.split()).lower()
log1 = newestBook.split(" ")
a16 = set(log1)
a16c = col.Counter(log1)


book = open("1016.txt", encoding='utf-8')
str = book.read()
regex = re.compile("[^a-zA-Z ']")
newBook = regex.sub(' ', str)
newestBook = " ".join(newBook.split()).lower()
log2 = newestBook.split(" ")
b16 = set(log2)
b16c = col.Counter(log2)


book = open("1030.txt", encoding='utf-8')
str = book.read()
regex = re.compile("[^a-zA-Z ']")
newBook = regex.sub(' ', str)
newestBook = " ".join(newBook.split()).lower()
log3 = newestBook.split(" ")
c16 = set(log3)
c16c = col.Counter(log3)


book = open("10039.txt", encoding='utf-8')
str = book.read()
regex = re.compile("[^a-zA-Z ']")
newBook = regex.sub(' ', str)
newestBook = " ".join(newBook.split()).lower()
log4 = newestBook.split(" ")
d16 = set(log4)
d16c = col.Counter(log4)


book = open("10615.txt", encoding='utf-8')
str = book.read()
regex = re.compile("[^a-zA-Z ']")
newBook = regex.sub(' ', str)
newestBook = " ".join(newBook.split()).lower()
log5 = newestBook.split(" ")
e16 = set(log5)
e16c = col.Counter(log5)


book = open("10616.txt", encoding='utf-8')
str = book.read()
regex = re.compile("[^a-zA-Z ']")
newBook = regex.sub(' ', str)
newestBook = " ".join(newBook.split()).lower()
log6 = newestBook.split(" ")
f16 = set(log6)
f16c = col.Counter(log6)


book = open("donQuix.txt", encoding='utf-8')
str = book.read()
regex = re.compile("[^a-zA-Z ']")
newBook = regex.sub(' ', str)
newestBook = " ".join(newBook.split()).lower()
log7 = newestBook.split(" ")
g16 = set(log7)
g16c = col.Counter(log7)


book = open("faustus.txt", encoding='utf-8')
str = book.read()
regex = re.compile("[^a-zA-Z ']")
newBook = regex.sub(' ', str)
newestBook = " ".join(newBook.split()).lower()
log8 = newestBook.split(" ")
h16 = set(log8)
h16c = col.Counter(log8)


book = open("paraLost.txt", encoding='utf-8')
str = book.read()
regex = re.compile("[^a-zA-Z ']")
newBook = regex.sub(' ', str)
newestBook = " ".join(newBook.split()).lower()
log9 = newestBook.split(" ")
i16 = set(log9)
i16c = col.Counter(log9)


book = open("pilgProg.txt", encoding='utf-8')
str = book.read()
regex = re.compile("[^a-zA-Z ']")
newBook = regex.sub(' ', str)
newestBook = " ".join(newBook.split()).lower()
log10 = newestBook.split(" ")
j16 = set(log10)
j16c = col.Counter(log10)


book = open("1079.txt", encoding='utf-8')
str = book.read()
regex = re.compile("[^a-zA-Z ']")
newBook = regex.sub(' ', str)
newestBook = " ".join(newBook.split()).lower()
log11 = newestBook.split(" ")
a17 = set(log11)
a17c = col.Counter(log11)


book = open("1080.txt", encoding='utf-8')
str = book.read()
regex = re.compile("[^a-zA-Z ']")
newBook = regex.sub(' ', str)
newestBook = " ".join(newBook.split()).lower()
log12 = newestBook.split(" ")
b17 = set(log12)
b17c = col.Counter(log12)


book = open("1090.txt", encoding='utf-8')
str = book.read()
regex = re.compile("[^a-zA-Z ']")
newBook = regex.sub(' ', str)
newestBook = " ".join(newBook.split()).lower()
log13 = newestBook.split(" ")
c17 = set(log13)
c17c = col.Counter(log13)


book = open("10010.txt", encoding='utf-8')
str = book.read()
regex = re.compile("[^a-zA-Z ']")
newBook = regex.sub(' ', str)
newestBook = " ".join(newBook.split()).lower()
log14 = newestBook.split(" ")
d17 = set(log14)
d17c = col.Counter(log14)


book = open("10069.txt", encoding='utf-8')
str = book.read()
regex = re.compile("[^a-zA-Z ']")
newBook = regex.sub(' ', str)
newestBook = " ".join(newBook.split()).lower()
log15 = newestBook.split(" ")
e17 = set(log15)
e17c = col.Counter(log15)


book = open("10072.txt", encoding='utf-8')
str = book.read()
regex = re.compile("[^a-zA-Z ']")
newBook = regex.sub(' ', str)
newestBook = " ".join(newBook.split()).lower()
log16 = newestBook.split(" ")
f17 = set(log16)
f17c = col.Counter(log16)


book = open("10075.txt", encoding='utf-8')
str = book.read()
regex = re.compile("[^a-zA-Z ']")
newBook = regex.sub(' ', str)
newestBook = " ".join(newBook.split()).lower()
log17 = newestBook.split(" ")
g17 = set(log17)
g17c = col.Counter(log17)


book = open("10318.txt", encoding='utf-8')
str = book.read()
regex = re.compile("[^a-zA-Z ']")
newBook = regex.sub(' ', str)
newestBook = " ".join(newBook.split()).lower()
log18 = newestBook.split(" ")
h17 = set(log18)
h17c = col.Counter(log18)


book = open("10357.txt", encoding='utf-8')
str = book.read()
regex = re.compile("[^a-zA-Z ']")
newBook = regex.sub(' ', str)
newestBook = " ".join(newBook.split()).lower()
log19 = newestBook.split(" ")
i17 = set(log19)
i17c = col.Counter(log19)


book = open("10451.txt", encoding='utf-8')
str = book.read()
regex = re.compile("[^a-zA-Z ']")
newBook = regex.sub(' ', str)
newestBook = " ".join(newBook.split()).lower()
log20 = newestBook.split(" ")
j17 = set(log20)
j17c = col.Counter(log20)


book = open("102.txt", encoding='utf-8')
str = book.read()
regex = re.compile("[^a-zA-Z ']")
newBook = regex.sub(' ', str)
newestBook = " ".join(newBook.split()).lower()
log21 = newestBook.split(" ")
a18 = set(log21)
a18c = col.Counter(log21)


book = open("103.txt", encoding='utf-8')
str = book.read()
newBook = regex.sub(' ', str)
newestBook = " ".join(newBook.split()).lower()
log22 = newestBook.split(" ")
b18 = set(log22)
b18c = col.Counter(log22)


book = open("105.txt", encoding='utf-8')
str = book.read()
newBook = regex.sub(' ', str)
newestBook = " ".join(newBook.split()).lower()
log23 = newestBook.split(" ")
c18 = set(log23)
c18c = col.Counter(log23)


book = open("107.txt", encoding='utf-8')
str = book.read()
newBook = regex.sub(' ', str)
newestBook = " ".join(newBook.split()).lower()
log24 = newestBook.split(" ")
d18 = set(log24)
d18c = col.Counter(log24)


book = open("1015.txt", encoding='utf-8')
str = book.read()
newBook = regex.sub(' ', str)
newestBook = " ".join(newBook.split()).lower()
log25 = newestBook.split(" ")
e18 = set(log25)
e18c = col.Counter(log25)


book = open("1017.txt", encoding='utf-8')
str = book.read()
newBook = regex.sub(' ', str)
newestBook = " ".join(newBook.split()).lower()
log26 = newestBook.split(" ")
f18 = set(log26)
f18c = col.Counter(log26)


book = open("1022.txt", encoding='utf-8')
str = book.read()
newBook = regex.sub(' ', str)
newestBook = " ".join(newBook.split()).lower()
log27 = newestBook.split(" ")
g18 = set(log27)
g18c = col.Counter(log27)


book = open("1023.txt", encoding='utf-8')
str = book.read()
newBook = regex.sub(' ', str)
newestBook = " ".join(newBook.split()).lower()
log28 = newestBook.split(" ")
h18 = set(log28)
h18c = col.Counter(log28)


book = open("1024.txt", encoding='utf-8')
str = book.read()
newBook = regex.sub(' ', str)
newestBook = " ".join(newBook.split()).lower()
log29 = newestBook.split(" ")
i18 = set(log29)
i18c = col.Counter(log29)


book = open("1026.txt", encoding='utf-8')
str = book.read()
newBook = regex.sub(' ', str)
newestBook = " ".join(newBook.split()).lower()
log30 = newestBook.split(" ")
j18 = set(log30)
j18c = col.Counter(log30)


book = open("101.txt", encoding='utf-8')
str = book.read()
newBook = regex.sub(' ', str)
newestBook = " ".join(newBook.split()).lower()
log31 = newestBook.split(" ")
a19 = set(log31)
a19c = col.Counter(log31)


book = open("106.txt", encoding='utf-8')
str = book.read()
newBook = regex.sub(' ', str)
newestBook = " ".join(newBook.split()).lower()
log32 = newestBook.split(" ")
b19 = set(log32)
b19c = col.Counter(log32)


book = open("108.txt", encoding='utf-8')
str = book.read()
newBook = regex.sub(' ', str)
newestBook = " ".join(newBook.split()).lower()
log33 = newestBook.split(" ")
c19 = set(log33)
c19c = col.Counter(log33)


book = open("109.txt", encoding='utf-8')
str = book.read()
newBook = regex.sub(' ', str)
newestBook = " ".join(newBook.split()).lower()
log34 = newestBook.split(" ")
d19 = set(log34)
d19c = col.Counter(log34)


book = open("1013.txt", encoding='utf-8')
str = book.read()
newBook = regex.sub(' ', str)
newestBook = " ".join(newBook.split()).lower()
log35 = newestBook.split(" ")
e19 = set(log35)
e19c = col.Counter(log35)


book = open("1014.txt", encoding='utf-8')
str = book.read()
newBook = regex.sub(' ', str)
newestBook = " ".join(newBook.split()).lower()
log36 = newestBook.split(" ")
f19 = set(log36)
f19c = col.Counter(log36)


book = open("1021.txt", encoding='utf-8')
str = book.read()
newBook = regex.sub(' ', str)
newestBook = " ".join(newBook.split()).lower()
log37 = newestBook.split(" ")
g19 = set(log37)
g19c = col.Counter(log37)


book = open("1027.txt", encoding='utf-8')
str = book.read()
newBook = regex.sub(' ', str)
newestBook = " ".join(newBook.split()).lower()
log38 = newestBook.split(" ")
h19 = set(log38)
h19c = col.Counter(log38)


book = open("1029.txt", encoding='utf-8')
str = book.read()
newBook = regex.sub(' ', str)
newestBook = " ".join(newBook.split()).lower()
log39 = newestBook.split(" ")
i19 = set(log39)
i19c = col.Counter(log39)


book = open("1031.txt", encoding='utf-8')
str = book.read()
newBook = regex.sub(' ', str)
newestBook = " ".join(newBook.split()).lower()
log40 = newestBook.split(" ")
j19 = set(log40)
j19c = col.Counter(log40)

"""
Section II: Noise Removal

There are some words that will occur in all of your
books: the, a, there... We go ahead and remove those
words because, frankly, they're useless. So, we get
the intersection of all our books, and add a few
extra words that probably occur in most of the books
that are also useless, like "chapter". We also try
to remove the possessive "s" that was dropped when
we got rid of apostrophes. Try being the operative
word. Again, she's not perfect. 

"""

ignore = list(a16.intersection(b16).intersection(c16).intersection(d16).intersection(e16).intersection(f16).intersection(g16).intersection(h16).intersection(i16).intersection(j16).intersection(a17).intersection(b17).intersection(c17).intersection(d17).intersection(e17).intersection(f17).intersection(g17).intersection(h17).intersection(i17).intersection(j17).intersection(a18).intersection(b18).intersection(c18).intersection(d18).intersection(e18).intersection(f18).intersection(g18).intersection(h18).intersection(i18).intersection(j18).intersection(a19).intersection(b19).intersection(c19).intersection(d19).intersection(e19).intersection(f19).intersection(g19).intersection(h19).intersection(i19).intersection(j19)) + ['s','t','th','st','mr','mrs','chapter']

bookList = [a16c,b16c,c16c,d16c,e16c,f16c,g16c,h16c,i16c,j16c,a17c,b17c,c17c,d17c,e17c,f17c,g17c,h17c,i17c,j17c,a18c,b18c,c18c,d18c,e18c,f18c,g18c,h18c,i18c,j18c,a19c,b19c,c19c,d19c,e19c,f19c,g19c,h19c,i19c,j19c]

for book in bookList:
    for word in list(book):
        if word in ignore:
            del book[word]

"""
Section III: Word Selection

For our model, we select the 100 most common words
from each book... Different results - perhaps even
better results - could be obtained using the least
common words.

"""

y1 = a16c.most_common(100)
y2 = b16c.most_common(100)
y3 = c16c.most_common(100)
y4 = d16c.most_common(100)
y5 = e16c.most_common(100)
y6 = f16c.most_common(100)
y7 = g16c.most_common(100)
y8 = h16c.most_common(100)
y9 = i16c.most_common(100)
y10 = j16c.most_common(100)
y11 = a17c.most_common(100)
y12 = b17c.most_common(100)
y13 = c17c.most_common(100)
y14 = d17c.most_common(100)
y15 = e17c.most_common(100)
y16 = f17c.most_common(100)
y17 = g17c.most_common(100)
y18 = h17c.most_common(100)
y19 = i17c.most_common(100)
y20 = j17c.most_common(100)
y21 = a18c.most_common(100)
y22 = b18c.most_common(100)
y23 = c18c.most_common(100)
y24 = d18c.most_common(100)
y25 = e18c.most_common(100)
y26 = f18c.most_common(100)
y27 = g18c.most_common(100)
y28 = h18c.most_common(100)
y29 = i18c.most_common(100)
y30 = j18c.most_common(100)
y31 = a19c.most_common(100)
y32 = b19c.most_common(100)
y33 = c19c.most_common(100)
y34 = d19c.most_common(100)
y35 = e19c.most_common(100)
y36 = f19c.most_common(100)
y37 = g19c.most_common(100)
y38 = h19c.most_common(100)
y39 = i19c.most_common(100)
y40 = j19c.most_common(100)

"""
Section IV: Matrix Creation

Don't bother looking at each of these... we just
turn our top 100 objects into a 2x100 matrix, and
set the words as the index. This was an extreme
pain in the rear. This is the last section's uglier
sister, but she's got great personality at least.

"""

df1 = pd.DataFrame({'word': list(list(zip(*y1))[0]), 'Book1': list(list(zip(*y1))[1])})
df1.set_index('word',inplace=True)

df2 = pd.DataFrame({'word': list(list(zip(*y2))[0]), 'Book2': list(list(zip(*y2))[1])})
df2.set_index('word',inplace=True)
df3 = pd.DataFrame({'word': list(list(zip(*y3))[0]), 'Book3': list(list(zip(*y3))[1])})
df3.set_index('word',inplace=True)
df4 = pd.DataFrame({'word': list(list(zip(*y4))[0]), 'Book4': list(list(zip(*y4))[1])})
df4.set_index('word',inplace=True)
df5 = pd.DataFrame({'word': list(list(zip(*y5))[0]), 'Book5': list(list(zip(*y5))[1])})
df5.set_index('word',inplace=True)
df6 = pd.DataFrame({'word': list(list(zip(*y6))[0]), 'Book6': list(list(zip(*y6))[1])})
df6.set_index('word',inplace=True)
df7 = pd.DataFrame({'word': list(list(zip(*y7))[0]), 'Book7': list(list(zip(*y7))[1])})
df7.set_index('word',inplace=True)
df8 = pd.DataFrame({'word': list(list(zip(*y8))[0]), 'Book8': list(list(zip(*y8))[1])})
df8.set_index('word',inplace=True)
df9 = pd.DataFrame({'word': list(list(zip(*y9))[0]), 'Book9': list(list(zip(*y9))[1])})
df9.set_index('word',inplace=True)
df10 = pd.DataFrame({'word': list(list(zip(*y10))[0]), 'Book10': list(list(zip(*y10))[1])})
df10.set_index('word',inplace=True)
df11 = pd.DataFrame({'word': list(list(zip(*y11))[0]), 'Book11': list(list(zip(*y11))[1])})
df11.set_index('word',inplace=True)
df12 = pd.DataFrame({'word': list(list(zip(*y12))[0]), 'Book12': list(list(zip(*y12))[1])})
df12.set_index('word',inplace=True)
df13 = pd.DataFrame({'word': list(list(zip(*y13))[0]), 'Book13': list(list(zip(*y13))[1])})
df13.set_index('word',inplace=True)
df14 = pd.DataFrame({'word': list(list(zip(*y14))[0]), 'Book14': list(list(zip(*y14))[1])})
df14.set_index('word',inplace=True)
df15 = pd.DataFrame({'word': list(list(zip(*y15))[0]), 'Book15': list(list(zip(*y15))[1])})
df15.set_index('word',inplace=True)
df16 = pd.DataFrame({'word': list(list(zip(*y16))[0]), 'Book16': list(list(zip(*y16))[1])})
df16.set_index('word',inplace=True)
df17 = pd.DataFrame({'word': list(list(zip(*y17))[0]), 'Book17': list(list(zip(*y17))[1])})
df17.set_index('word',inplace=True)
df18 = pd.DataFrame({'word': list(list(zip(*y18))[0]), 'Book18': list(list(zip(*y18))[1])})
df18.set_index('word',inplace=True)
df19 = pd.DataFrame({'word': list(list(zip(*y19))[0]), 'Book19': list(list(zip(*y19))[1])})
df19.set_index('word',inplace=True)
df20 = pd.DataFrame({'word': list(list(zip(*y20))[0]), 'Book20': list(list(zip(*y20))[1])})
df20.set_index('word',inplace=True)
df21 = pd.DataFrame({'word': list(list(zip(*y21))[0]), 'Book21': list(list(zip(*y21))[1])})
df21.set_index('word',inplace=True)
df22 = pd.DataFrame({'word': list(list(zip(*y22))[0]), 'Book22': list(list(zip(*y22))[1])})
df22.set_index('word',inplace=True)
df23 = pd.DataFrame({'word': list(list(zip(*y23))[0]), 'Book23': list(list(zip(*y23))[1])})
df23.set_index('word',inplace=True)
df24 = pd.DataFrame({'word': list(list(zip(*y24))[0]), 'Book24': list(list(zip(*y24))[1])})
df24.set_index('word',inplace=True)
df25 = pd.DataFrame({'word': list(list(zip(*y25))[0]), 'Book25': list(list(zip(*y25))[1])})
df25.set_index('word',inplace=True)
df26 = pd.DataFrame({'word': list(list(zip(*y26))[0]), 'Book26': list(list(zip(*y26))[1])})
df26.set_index('word',inplace=True)
df27 = pd.DataFrame({'word': list(list(zip(*y27))[0]), 'Book27': list(list(zip(*y27))[1])})
df27.set_index('word',inplace=True)
df28 = pd.DataFrame({'word': list(list(zip(*y28))[0]), 'Book28': list(list(zip(*y28))[1])})
df28.set_index('word',inplace=True)
df29 = pd.DataFrame({'word': list(list(zip(*y29))[0]), 'Book29': list(list(zip(*y29))[1])})
df29.set_index('word',inplace=True)
df30 = pd.DataFrame({'word': list(list(zip(*y30))[0]), 'Book30': list(list(zip(*y30))[1])})
df30.set_index('word',inplace=True)
df31 = pd.DataFrame({'word': list(list(zip(*y31))[0]), 'Book31': list(list(zip(*y31))[1])})
df31.set_index('word',inplace=True)
df32 = pd.DataFrame({'word': list(list(zip(*y32))[0]), 'Book32': list(list(zip(*y32))[1])})
df32.set_index('word',inplace=True)
df33 = pd.DataFrame({'word': list(list(zip(*y33))[0]), 'Book33': list(list(zip(*y33))[1])})
df33.set_index('word',inplace=True)
df34 = pd.DataFrame({'word': list(list(zip(*y34))[0]), 'Book34': list(list(zip(*y34))[1])})
df34.set_index('word',inplace=True)
df35 = pd.DataFrame({'word': list(list(zip(*y35))[0]), 'Book35': list(list(zip(*y35))[1])})
df35.set_index('word',inplace=True)
df36 = pd.DataFrame({'word': list(list(zip(*y36))[0]), 'Book36': list(list(zip(*y36))[1])})
df36.set_index('word',inplace=True)
df37 = pd.DataFrame({'word': list(list(zip(*y37))[0]), 'Book37': list(list(zip(*y37))[1])})
df37.set_index('word',inplace=True)
df38 = pd.DataFrame({'word': list(list(zip(*y38))[0]), 'Book38': list(list(zip(*y38))[1])})
df38.set_index('word',inplace=True)
df39 = pd.DataFrame({'word': list(list(zip(*y39))[0]), 'Book39': list(list(zip(*y39))[1])})
df39.set_index('word',inplace=True)
df40 = pd.DataFrame({'word': list(list(zip(*y40))[0]), 'Book40': list(list(zip(*y40))[1])})
df40.set_index('word',inplace=True)

"""
Section V: Finale

Congratulations. You did it. We take all of the
DataFrames from the previous section and concatenate
them. It's a beautiful result for the most part.
The concatenated matrix is then printed to a .csv

"""

frames = [df1,df2,df3,df4,df5,df6,df7,df8,df9,df10,df11,df12,df13,df14,df15,df16,df17,df18,df19,df20,df21,df22,df23,df24,df25,df26,df27,df28,df29,df30,df31,df32,df33,df34,df35,df36,df37,df38,df39,df40]

data = pd.concat(frames,axis=1)

dataset = data.transpose()

dataset.to_csv('dataset.csv')
